from django.db.models.signals import post_save, pre_delete
from django.dispatch import receiver
from account.models import User, TeacherProfile, StudentProfile


@receiver(post_save, sender=User)
def create_profile(sender, instance, created, **kwargs):
    if created:
        if instance.role=="teacher":
            TeacherProfile.objects.create(teacher_id=instance)
        elif instance.role=="student":
            StudentProfile.objects.create(roll_no=instance)

@receiver(pre_delete, sender=User)
def delete_profile(sender, instance, **kwargs):
    if hasattr(instance, 'teacherprofile'):
        instance.teacherprofile.delete()
    if hasattr(instance, 'studentprofile'):
        instance.studentprofile.delete()