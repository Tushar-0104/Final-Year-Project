from django.db import models
from django.contrib.auth.models import AbstractUser

# Create your models here.


class User(AbstractUser):
    role = models.CharField(max_length=20, choices=[("admin", "Admin"), 
                                                      ("teacher", "Teacher"),
                                                      ("student", "Student")], 
                                                      default="student")


class TeacherProfile(models.Model):
    teacher_id = models.OneToOneField(User, on_delete=models.CASCADE)
    firat_name = models.CharField(max_length=50, blank=True)
    last_name = models.CharField(max_length=50, blank=True)
    class_name = models.CharField(max_length=5, blank=True)

    def save(self, *args, **kwargs):
        if not self.teacher_id.role=="teacher":
            raise ValueError("A teacher profile must be associated with a teacher user.")
        super().save(*args, **kwargs)

    def __str__(self):
        return self.teacher_id.username
    

class StudentProfile(models.Model):
    roll_no = models.OneToOneField(User, on_delete=models.CASCADE)
    firat_name = models.CharField(max_length=50, blank=True)
    last_name = models.CharField(max_length=50, blank=True)
    class_name = models.CharField(max_length=5, blank=True)
    photographs = models.FileField(upload_to='photographs', blank=True)

    def save(self, *args, **kwargs):
        if not self.roll_no.role=="student":
            raise ValueError("A student profile must be associated with a student user.")
        super().save(*args, **kwargs)

    def __str__(self):
        return self.roll_no.username
    
class Profile_obj(models.Model):
    user = models.OneToOneField(User,on_delete=models.CASCADE)
    token = models.CharField(max_length=100)
    data = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.user.username
    
class Attendance(models.Model):
    roll_no = models.CharField(max_length=50, blank=True)
    class_name = models.CharField(max_length=5, blank=True)
    attendance = models.CharField(max_length=1, blank=True)
    date = models.DateField(blank=True)

    def __str__(self):

        return f"{self.roll_no} - {self.date}"


