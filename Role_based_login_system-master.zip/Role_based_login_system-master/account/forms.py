from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import User, StudentProfile, TeacherProfile, Attendance

class LoginForm(forms.Form):
    username = forms.CharField(
        widget= forms.TextInput(
            attrs={
                "class": "form-control"
            }
        )
    )
    password = forms.CharField(
        widget=forms.PasswordInput(
            attrs={
                "class": "form-control"
            }
        )
    )


class SignUpForm(UserCreationForm):
    username = forms.CharField(
        widget=forms.TextInput(
            attrs={
                "class": "form-control"
            }
        )
    )
    password1 = forms.CharField(
        widget=forms.PasswordInput(
            attrs={
                "class": "form-control"
            }
        )
    )
    password2 = forms.CharField(
        widget=forms.PasswordInput(
            attrs={
                "class": "form-control"
            }
        )
    )
    email = forms.CharField(
        widget=forms.TextInput(
            attrs={
                "class": "form-control"
            }
        )
    )

    class Meta:
        model = User
        fields = ('username', 'email', 'password1', 'password2', 'role')
        widgets = {

            'status':forms.Select(attrs={'class':'form-control'})
        
        }


class TeacherForm(forms.ModelForm):

    class Meta:

        model = TeacherProfile
        fields = ('__all__')
        exclude = ('teacher_id',)


class StudentForm(forms.ModelForm):

    class Meta:

        model = StudentProfile
        fields = ('__all__')
        exclude = ('roll_no',)

class AttendanceForm(forms.Form):
    roll_no = forms.CharField(max_length=50)
    date = forms.DateField()
    new_attendance_value = forms.CharField(max_length=1)