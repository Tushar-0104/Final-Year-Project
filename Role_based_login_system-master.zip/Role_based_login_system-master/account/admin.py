from django.contrib import admin
from .models import User, TeacherProfile, StudentProfile, Profile_obj, Attendance

# Register your models here.
admin.site.register(User)
admin.site.register(TeacherProfile)
admin.site.register(StudentProfile)
admin.site.register(Profile_obj)
admin.site.register(Attendance)
