from django.shortcuts import render, redirect, HttpResponse, get_object_or_404
from .forms import SignUpForm, LoginForm, StudentForm, TeacherForm, AttendanceForm
from django.contrib.auth import authenticate, login
from django.contrib import messages
from .models import TeacherProfile,StudentProfile,Profile_obj,User, Attendance
from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout
from .helpers import send_forget_password_mail
from datetime import datetime, timedelta
# Create your views here.


def index(request):
    return render(request, 'index.html')

@login_required
def register(request):
    msg = None
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save()
            msg = 'user created'
            emp = form.cleaned_data['role']
            if emp=="student":
                return redirect(f'/studentprofile/{user.id}/')
            elif emp=="teacher":
                return redirect(f'/teacherprofile/{user.id}/')
        else:
            msg = 'form is not valid'
    else:
        form = SignUpForm()
    return render(request,'register.html', {'form': form, 'msg': msg})


def login_view(request):
    form = LoginForm(request.POST or None)
    msg = None
    if request.method == 'POST':
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None and user.role=="admin":
                login(request, user)
                return redirect("/junioradmin/")
            elif user is not None and user.role=="teacher":
                login(request, user)
                return redirect('/teacher/')
            elif user is not None and user.role=="student":
                login(request, user)
                return redirect('/student/')
            elif not username or not password:
                messages.success(request,'Both field are required')
            else:
                messages.success(request,'wrong credentials !!!')
        else:
            msg = 'error validating form'
    else:
        form = LoginForm()
    return render(request, 'login.html', {'form': form, 'msg': msg})

@login_required
def student_form(request,id):
    if request.method == "POST":
        form_data = StudentProfile.objects.get(roll_no=id)
        form = StudentForm(request.POST,instance = form_data)
        if form.is_valid():
            form.save()
            messages.success(request,'Data updated !')
            return redirect("/junioradmin/")
    form_data = StudentProfile.objects.get(roll_no=id)
    form = StudentForm(instance=form_data)
    return render(request,'studentprofile.html',{'form':form, 'roll_no': form_data.roll_no})

@login_required
def teacher_form(request,id):
    if request.method == "POST":
        form_data = TeacherProfile.objects.get(teacher_id=id)
        form = TeacherForm(request.POST,instance = form_data)
        if form.is_valid():
            form.save()
            messages.success(request,'Data updated !')
            return redirect("/junioradmin/")
        else:
            messages.success(request,'wrong credentials !!!')
    
    form_data = TeacherProfile.objects.get(teacher_id=id)
    form = TeacherForm(instance=form_data)
    return render(request,'teacherprofile.html',{'form':form,'teacher_id': form_data.teacher_id})


def logout_view(request):
    logout(request)
    return redirect('/')


import uuid
def forgetpassword(request):
    if request.method == "POST":
        uname = request.POST['username']
        user = User.objects.filter(username=uname).first()

        if user is None:
            messages.success(request,'user not found')

        else:
            user_obj = User.objects.get(username=uname)
            print(user_obj)
            token = str(uuid.uuid4())
            print(token)
            profile_obj, created = Profile_obj.objects.get_or_create(user=user)
            profile_obj.token = token
            profile_obj.save()
            send_forget_password_mail(user_obj.email,token)
            messages.success(request,'Message sent')
            #return redirect('/forget-password/')

    return render(request,'forget_password.html')


def changepassword(request,token):
    
    if request.method == "POST":
        new_password = request.POST['new_password']
        confirm_password = request.POST['re-confirm_password']
        user_id = request.POST['user_id']

        if user_id is None:
            messages.success(request,'No user id found')
            return redirect(f'/change-password/{token}/')
        
        if new_password != confirm_password:
            messages.success(request,'both should be equal')
            return redirect(f'/change-password/{token}/')
        
        user_obj = User.objects.get(id=user_id)
        user_obj.set_password(new_password)
        user_obj.save()
        return redirect('/login/')
        
    

    profile_obj = Profile_obj.objects.filter(token=token).first()
    context = {

        'user_id':profile_obj.user.id
    }
    return render(request,'change_password.html',context)

@login_required
def student_view(request):
    if request.method == 'POST':
        start_date = request.POST.get('start_date')
        end_date = request.POST.get('end_date')

        attendance_data = Attendance.objects.filter(roll_no=request.user, date__range=[start_date, end_date])
        if attendance_data == None:
            messages.success(request,'No data found')
        else:
            return render(request, 'student.html', {'attendance_data': attendance_data, 'user':request.user})
    else:
        today = datetime.today()
        days_until_sunday = 6 - today.weekday()
        start_date = today - timedelta(days=today.weekday())
        end_date = start_date + timedelta(days=6)
        attendance_data = Attendance.objects.filter(roll_no=request.user, date__range=[start_date, end_date])
        if not attendance_data.exists():
            messages.success(request,'No data found')
        else:
            return render(request, 'student.html', {'attendance_data': attendance_data, 'user':request.user})


@login_required
def teacher_view(request):
    if request.method == 'POST':
        start_date = request.POST.get('start_date')
        class_name = request.POST.get('class_name')
        attendance_data = Attendance.objects.filter(class_name=class_name,date=start_date)
        if attendance_data == None:
            messages.success(request,'No data found')
        else:
            return render(request, 'teacher.html', {'attendance_data': attendance_data, 'user':request.user})
    else:
        return render(request, 'teacher.html', {'user':request.user})
        

@login_required
def admin_view(request):
    return render(request,'admin.html')

def update_attendance(request):
    if request.method == 'POST':
        form = AttendanceForm(request.POST)
        if form.is_valid():
            roll_no = form.cleaned_data['roll_no']
            date = form.cleaned_data['date']
            new_attendance_value = form.cleaned_data['new_attendance_value']

            attendance = get_object_or_404(Attendance, roll_no=roll_no, date=date)
            attendance.attendance = new_attendance_value
            attendance.save()

            return render(request, 'attendance_update.html', {'attendance': attendance})
    else:
        form = AttendanceForm()
        return render(request, 'update_attendance.html', {'form': form})